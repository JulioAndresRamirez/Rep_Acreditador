from django.db import models

# Create your models here.


# class Acreditadores(models.Model):
#     run = models.CharField(max_length=10)
#     nombre = models.CharField(max_length=255, blank=True, null=True)
#     # Asosciar a un evento de forma no obligatoria