from django.apps import AppConfig


class EventoConfig(AppConfig):
    name = 'evento'
